Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 3
Config.MarkerSize                 = { x = 21.0, y = 2.0, z = 1.0 }
Config.MarkerColor                = { r = 231, g = 137, b = 255 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = false -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = false
Config.MaxInService               = -1
Config.Locale                     = 'fr'

Config.ballasStations = {

  ballas = {

    Blip = {
      Pos     = { x = 101.70, y = -1937.35, z = 20.80},
      Sprite  = -1,
      Display = 4,
      Scale   = 1.2,
      Colour  = 29,
    },

    AuthorizedWeapons = {
      { name = 'WEAPON_KNIFE',      price = 8000 },
      { name = 'WEAPON_BAT',      price = 8000 },
      { name = 'WEAPON_SNSPISTOL',      price = 50000 },
      },

	  AuthorizedVehicles = {
		  { name = 'Enus Stafford',    label = 'Voitures' },
      { name = 'Albany Roosvelt Valor',    label = 'Voitures' },
      { name = 'Cosgnoscenti 55',    label = 'Voitures' },
      { name = 'Enus Furore GT',    label = 'Voitures' },
      { name = 'Dundreary Stretch',    label = 'Voitures' },
      { name = 'Shitzu Hakuchou',    label = 'Motos' },
      { name = ' Bravado Rumpo Custom',    label = 'Vans' },
      { name = 'Canis Freecrawler',    label = '4x4' },
      { name = 'Baller LE',    label = '4x4' },
		  { name = 'Mammoth Patriot',  label = '4x4' },
		  { name = 'Vapid Contender',     label = '4x4' },
	  },


    Armories = {
      { x = 106.3972, y = -1981.2757, z = 20.9626}, -- Armurerie
    },

    Vehicles = {
      {
        Spawner    = { x = 84.616561889648, y = -1966.8900146484, z = 20.747447967529 }, -- Menu véhicules
        SpawnPoint = { x = 87.737426757813, y = -1968.3201904297, z = 20.747457504272 }, -- Point d'apparitions
        Heading    = 315.699890, -- Angle d'apparation
      }
    },

    VehicleDeleters = {
      { x = 87.737426757813, y = -1968.3201904297, z = 20.747457504272 }, -- Ranger véhicule
    },

    BossActions = {
      { x = -214.5163, y = -4427.4062, z = -3.4704 }, -- Actions Patron
    },

  },

}