Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 3
Config.MarkerSize                 = { x = 21.0, y = 2.0, z = 1.0 }
Config.MarkerColor                = { r = 231, g = 137, b = 255 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = false -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = false
Config.MaxInService               = -1
Config.Locale                     = 'fr'

Config.GuériniStations = {

  Guérini = {

    Blip = {
      Pos     = { x = 376.85513305664, y = 12.291802406311, z = 91.977653503418},
      Sprite  = -1,
      Display = 4,
      Scale   = 1.2,
      Colour  = 29,
    },

	  AuthorizedVehicles = {
		  { name = 'Enus Stafford',    label = 'Voitures' },
      { name = 'Albany Roosvelt Valor',    label = 'Voitures' },
      { name = 'Cosgnoscenti 55',    label = 'Voitures' },
      { name = 'Enus Furore GT',    label = 'Voitures' },
      { name = 'Dundreary Stretch',    label = 'Voitures' },
      { name = 'Shitzu Hakuchou',    label = 'Motos' },
      { name = ' Bravado Rumpo Custom',    label = 'Vans' },
      { name = 'Canis Freecrawler',    label = '4x4' },
      { name = 'Baller LE',    label = '4x4' },
		  { name = 'Mammoth Patriot',  label = '4x4' },
		  { name = 'Vapid Contender',     label = '4x4' },
	  },


    Armories = {
      { x = 412.04196166992, y = 4.5067090988159, z = 84.921501159668}, -- Armurerie
    },

    Vehicles = {
      {
        Spawner    = { x = 360.4479675293, y = -23.229236602783, z = 82.993232727051 }, -- Menu véhicules
        SpawnPoint = { x = 364.0390625, y = -20.676412582397, z = 82.992210388184 }, -- Point d'apparitions
        Heading    = 315.699890, -- Angle d'apparation
      }
    },

    VehicleDeleters = {
      { x = 367.08193969727, y = -17.98025894165, z = 82.993232727051 }, -- Ranger véhicule
    },

    BossActions = {
      { x = 431.04067993164, y = 6.767297744751, z = 91.93529510498 }, -- Actions Patron
    },

  },

}